package com.myaccounts.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private int navy = Color.rgb(20,33,58);
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        showSplash();
        new Handler().postDelayed(this::loadApp, 950);
    }
    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(navy);
        TextView logo = new TextView(this);
        logo.setText("MY\nACCOUNTS");
        logo.setTextColor(Color.WHITE); logo.setTextSize(30); logo.setGravity(Gravity.CENTER);
        logo.setTypeface(null, 1);
        TextView sub = new TextView(this);
        sub.setText("حساباتك… تحت السيطرة");
        sub.setTextColor(Color.rgb(150,180,240)); sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        splash.addView(logo);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2,-2); p.topMargin=20;
        splash.addView(sub,p);
        root.addView(splash,new FrameLayout.LayoutParams(-1,-1));
    }
    private void loadApp() {
        webView = new WebView(this);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(),"Native");
        root.removeAllViews(); root.addView(webView,new FrameLayout.LayoutParams(-1,-1));
        webView.loadUrl("file:///android_asset/index.html");
    }
    class Bridge {
        @JavascriptInterface public void toast(String message) {
            runOnUiThread(()->Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show());
        }
    }
    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
